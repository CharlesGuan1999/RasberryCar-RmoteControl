package com.example.remote_control;

import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import java.net.Socket;

import android.os.Build;
import android.view.Window;
import android.view.WindowManager;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import com.example.remote_control.control.*;

public class MainActivity extends AppCompatActivity {


    private TextView tv;
    private TextView tv_connect;//连接状态
    private TextView tv_play;//运动状态
    private Button btn_stop;//停止按钮
    private Rudder rudder;//摇杆控件
    private Handler handler;//消息机制

    private static String forward = "1";//前进
    private static String back = "2";//后退
    private static String left = "3";//左转
    private static String right = "4";//右转
    private static String stop="5";//停止

    private String send_buff = null;//发送的消息
    private String recv_buff = null;//接收的消息
    private Socket socket = null;//套接字，用于树莓派与安卓之间通信


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //透明状态栏
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window window = getWindow();
            window.setFlags(
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        init();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //192.168.43.156
                    socket = new Socket("192.168.137.221", 8888);
                    if (socket != null) {
                        while (true) {      //循环进行收发
                            recv();
                            Thread.sleep(50);
                        }
                    } else
                        System.out.println("socket is null");
                }

                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

        rudder.setRudderListener(new Rudder.RudderListener() {

            @Override
            public void onSteeringWheelChanged(int action, final int angle) {
                if (action == Rudder.ACTION_RUDDER) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            tv.setText(String.valueOf("角度值：" + angle));
                        }
                    });

                    if ((angle > 315 && angle < 360) || (angle > 0 && angle < 45)) {//右转
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                send_buff = right;
                                OutputStream outputStream = null;
                                try {
                                    outputStream = socket.getOutputStream();

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                if (outputStream != null) {
                                    try {
                                        outputStream.write(send_buff.getBytes());
                                        outputStream.flush();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }).start();

                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                tv_play.setText("运动状态：正在右转....");
                            }
                        });
                    }

                    if (angle > 45 && angle < 135) {//前进
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                send_buff = forward;
                                OutputStream outputStream = null;
                                try {
                                    outputStream = socket.getOutputStream();

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                if (outputStream != null) {
                                    try {
                                        outputStream.write(send_buff.getBytes());
                                        outputStream.flush();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }).start();

                        handler.post(new Runnable() {
                            @Override
                            public void run() {

                                tv_play.setText("运动状态：正在前进....");

                            }

                        });

                    }

                    if (angle > 135 && angle < 225) {//左转

                        new Thread(new Runnable() {

                            @Override

                            public void run() {

                                send_buff = left;

                                OutputStream outputStream = null;

                                try {

                                    outputStream = socket.getOutputStream();

                                } catch (IOException e) {

                                    e.printStackTrace();

                                }

                                if (outputStream != null) {

                                    try {

                                        outputStream.write(send_buff.getBytes());

                                        outputStream.flush();

                                    } catch (IOException e) {

                                        e.printStackTrace();

                                    }

                                }

                            }

                        }).start();



                        handler.post(new Runnable() {

                            @Override

                            public void run() {

                                tv_play.setText("运动状态：正在左转....");

                            }

                        });

                    }

                    if (angle > 225 && angle < 315) {//后退

                        new Thread(new Runnable() {

                            @Override

                            public void run() {

                                send_buff = back;

                                OutputStream outputStream = null;

                                try {

                                    outputStream = socket.getOutputStream();

                                } catch (IOException e) {

                                    e.printStackTrace();

                                }

                                if (outputStream != null) {

                                    try {

                                        outputStream.write(send_buff.getBytes());

                                        outputStream.flush();

                                    } catch (IOException e) {

                                        e.printStackTrace();

                                    }

                                }

                            }

                        }).start();

                        handler.post(new Runnable() {

                            @Override

                            public void run() {

                                tv_play.setText("运动状态：正在后退....");

                            }

                        });
                    }


                    if (angle == -1) {//自动停止

                        new Thread(new Runnable() {

                            @Override

                            public void run() {

                                send_buff = stop;

                                OutputStream outputStream = null;

                                try {

                                    outputStream = socket.getOutputStream();

                                } catch (IOException e) {

                                    e.printStackTrace();

                                }

                                if (outputStream != null) {

                                    try {

                                        outputStream.write(send_buff.getBytes());

                                        outputStream.flush();

                                    } catch (IOException e) {

                                        e.printStackTrace();

                                    }

                                }

                            }

                        }).start();

                        handler.post(new Runnable() {

                            @Override

                            public void run() {

                                tv_play.setText("离开屏幕，停止....");

                            }

                        });
                    }

                }
            }
        });



        btn_stop.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                new Thread(new Runnable() {

                    @Override

                    public void run() {

                        send_buff = stop;

                        OutputStream outputStream = null;

                        try {

                            outputStream = socket.getOutputStream();

                        } catch (IOException e) {

                            e.printStackTrace();

                        }

                        if (outputStream != null) {

                            try {

                                outputStream.write(send_buff.getBytes());

                                outputStream.flush();

                            } catch (IOException e) {

                                e.printStackTrace();

                            }

                        }

                    }

                }).start();

                handler.post(new Runnable() {

                    @Override

                    public void run() {

                        tv_play.setText("运动状态：停止....");

                    }

                });

            }

        });

    }

    private void init() {

        tv = findViewById(R.id.tv);
        tv_connect = findViewById(R.id.tv_connect);
        tv_play = findViewById(R.id.tv_play);
        btn_stop=findViewById(R.id.btn_stop);
        handler = new Handler();
        rudder = findViewById(R.id.rudder);

    }



    private void recv() {

        //单开一个线程循环接收来自服务器端的消息

        InputStream inputStream = null;

        try {

            inputStream = socket.getInputStream();

        } catch (IOException e) {

            e.printStackTrace();

        }



        if (inputStream != null) {

            try {

                byte[] buffer = new byte[1024];

                int count = inputStream.read(buffer);//count是传输的字节数

                recv_buff = new String(buffer);//socket通信传输的是byte类型，需要转为String类型

            } catch (IOException e) {

                e.printStackTrace();

            }

        }

        //显示连接状态

        if (recv_buff != null) {

            handler.post(runnableUi);

        }

    }

    //利用handler刷新UI

    Runnable runnableUi = new Runnable() {

        @Override

        public void run() {

            tv_connect.append(recv_buff);

        }

    };

}




